
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.createElement('button');
  btn.textContent = '🌓';
  btn.className = 'toggle-dark';
  btn.onclick = () => document.body.classList.toggle('dark-mode');
  document.body.appendChild(btn);
});
