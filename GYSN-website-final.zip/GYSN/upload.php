<?php
$target_dir = "uploads/";
if (!file_exists($target_dir)) {
    mkdir($target_dir);
}
$target_file = $target_dir . basename($_FILES["myfile"]["name"]);
if (move_uploaded_file($_FILES["myfile"]["tmp_name"], $target_file)) {
    echo "An daura fayil ɗin da kyau.<br>";
    echo "<a href='downloads.html'>⬇️ Duba Duk Fayiloli</a>";
} else {
    echo "An samu matsala wajen daura fayil.";
}
?>